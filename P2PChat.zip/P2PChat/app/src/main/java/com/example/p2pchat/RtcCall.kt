package com.example.p2pchat

import android.content.Context
import org.json.JSONObject
import org.webrtc.*

open class SdpObs : SdpObserver {
    override fun onCreateSuccess(s: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(e: String?) {}
    override fun onSetFailure(e: String?) {}
}

/** One 1-to-1 call. Audio/video flow directly phone-to-phone over WebRTC. */
class RtcCall(
    ctx: Context, private val peer: String, private val video: Boolean, private val egl: EglBase,
    private val onLocal: (VideoTrack) -> Unit,
    private val onRemote: (VideoTrack) -> Unit
) {
    private val factory: PeerConnectionFactory
    private val pc: PeerConnection
    private var capturer: CameraVideoCapturer? = null
    private var helper: SurfaceTextureHelper? = null
    private var remoteSet = false
    private val pending = mutableListOf<IceCandidate>()

    init {
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions())
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext))
            .createPeerConnectionFactory()
        // STUN only. Add a TURN server below for strict/mobile-carrier NATs.
        val ice = listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
        val cfg = PeerConnection.RTCConfiguration(ice).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }
        pc = factory.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                Signaling.send(peer, "ice", JSONObject().put("mid", c.sdpMid).put("idx", c.sdpMLineIndex).put("sdp", c.sdp))
            }
            override fun onTrack(t: RtpTransceiver) { (t.receiver.track() as? VideoTrack)?.let(onRemote) }
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(d: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
        })!!

        val audio = factory.createAudioTrack("a0", factory.createAudioSource(MediaConstraints()))
        pc.addTrack(audio, listOf("s"))
        if (video) {
            val enumr = Camera2Enumerator(ctx)
            val name = enumr.deviceNames.firstOrNull { enumr.isFrontFacing(it) } ?: enumr.deviceNames.first()
            capturer = enumr.createCapturer(name, null)
            helper = SurfaceTextureHelper.create("cap", egl.eglBaseContext)
            val src = factory.createVideoSource(false)
            capturer!!.initialize(helper, ctx, src.capturerObserver)
            capturer!!.startCapture(640, 480, 30)
            val vt = factory.createVideoTrack("v0", src)
            pc.addTrack(vt, listOf("s"))
            onLocal(vt)
        }
    }

    fun offer() {
        pc.createOffer(object : SdpObs() {
            override fun onCreateSuccess(s: SessionDescription) {
                pc.setLocalDescription(SdpObs(), s)
                Signaling.send(peer, "offer", JSONObject().put("sdp", s.description))
            }
        }, MediaConstraints())
    }

    fun onSignal(type: String, d: JSONObject) {
        when (type) {
            "offer" -> pc.setRemoteDescription(object : SdpObs() {
                override fun onSetSuccess() {
                    flush()
                    pc.createAnswer(object : SdpObs() {
                        override fun onCreateSuccess(s: SessionDescription) {
                            pc.setLocalDescription(SdpObs(), s)
                            Signaling.send(peer, "answer", JSONObject().put("sdp", s.description))
                        }
                    }, MediaConstraints())
                }
            }, SessionDescription(SessionDescription.Type.OFFER, d.getString("sdp")))
            "answer" -> pc.setRemoteDescription(object : SdpObs() {
                override fun onSetSuccess() { flush() }
            }, SessionDescription(SessionDescription.Type.ANSWER, d.getString("sdp")))
            "ice" -> {
                val c = IceCandidate(d.getString("mid"), d.getInt("idx"), d.getString("sdp"))
                if (remoteSet) pc.addIceCandidate(c) else pending += c
            }
        }
    }

    private fun flush() { remoteSet = true; pending.forEach { pc.addIceCandidate(it) }; pending.clear() }

    fun close() {
        runCatching { capturer?.stopCapture() }
        capturer?.dispose(); helper?.dispose()
        pc.close(); pc.dispose(); factory.dispose()
    }
}
