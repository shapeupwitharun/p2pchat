package com.example.p2pchat

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONObject
import org.webrtc.*

class MainActivity : ComponentActivity() {
    private val egl = EglBase.create()
    private lateinit var db: Db
    private var myId by mutableStateOf("")
    private var chatPeer by mutableStateOf<String?>(null)
    private var incoming by mutableStateOf<Pair<String, Boolean>?>(null)
    private var call by mutableStateOf<RtcCall?>(null)
    private var localTrack by mutableStateOf<VideoTrack?>(null)
    private var remoteTrack by mutableStateOf<VideoTrack?>(null)
    private var tick by mutableStateOf(0)
    private var pendingVideo = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            .launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        db = Db(this)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        myId = prefs.getString("id", null) ?: (100000..999999).random().toString().also { prefs.edit().putString("id", it).apply() }
        Signaling.onMessage = ::handle
        Signaling.connect(myId)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Root() } } }
    }

    private fun handle(m: JSONObject) {
        val from = m.optString("from"); val d = m.optJSONObject("data") ?: JSONObject()
        when (m.getString("type")) {
            "msg" -> { db.add(from, false, d.getString("text")); tick++ }
            "call" -> if (call != null || incoming != null) Signaling.send(from, "busy") else incoming = from to d.optBoolean("video")
            "accept" -> startCall(from, pendingVideo, caller = true)
            "reject", "busy", "end" -> endCall(false)
            "offline" -> Toast.makeText(this, "$from is offline", Toast.LENGTH_SHORT).show().also { endCall(false) }
            "offer", "answer", "ice" -> call?.onSignal(m.getString("type"), d)
        }
    }

    private fun startCall(peer: String, video: Boolean, caller: Boolean) {
        chatPeer = peer
        call = RtcCall(this, peer, video, egl, { localTrack = it }, { remoteTrack = it }).also { if (caller) it.offer() }
    }
    private fun endCall(notify: Boolean) {
        if (notify) chatPeer?.let { Signaling.send(it, "end") }
        call?.close(); call = null; localTrack = null; remoteTrack = null; incoming = null
    }

    override fun onDestroy() { endCall(false); super.onDestroy() }

    @Composable
    fun Root() {
        if (call != null || (chatPeer != null && pendingVideo && call == null && false)) CallScreen()
        else if (chatPeer != null) ChatScreen(chatPeer!!)
        else HomeScreen()
        incoming?.let { (from, vid) ->
            AlertDialog(onDismissRequest = {}, title = { Text("Incoming ${if (vid) "video" else "voice"} call") },
                text = { Text("From $from") },
                confirmButton = { Button(onClick = { incoming = null; Signaling.send(from, "accept"); startCall(from, vid, false) }) { Text("Accept") } },
                dismissButton = { TextButton(onClick = { incoming = null; Signaling.send(from, "reject") }) { Text("Reject") } })
        }
    }

    @Composable
    fun HomeScreen() {
        var target by remember { mutableStateOf("") }
        val peers = remember(tick, chatPeer) { db.peers() }
        Column(Modifier.padding(16.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Your ID: $myId", style = MaterialTheme.typography.headlineSmall)
            Text("Share this ID with a friend, or enter theirs below.")
            OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("Friend's ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = { if (target.isNotBlank()) chatPeer = target }, Modifier.fillMaxWidth()) { Text("Open chat") }
            Text("Recent", style = MaterialTheme.typography.titleMedium)
            LazyColumn { items(peers) { p -> Text(p, Modifier.fillMaxWidth().clickable { chatPeer = p }.padding(12.dp)) } }
        }
    }

    @Composable
    fun ChatScreen(peer: String) {
        var text by remember { mutableStateOf("") }
        val msgs = remember(tick, chatPeer) { db.list(peer) }
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { chatPeer = null }) { Text("Back") }
                Text(peer, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = { pendingVideo = false; Signaling.send(peer, "call", JSONObject().put("video", false)); }) { Text("Voice") }
                TextButton(onClick = { pendingVideo = true; Signaling.send(peer, "call", JSONObject().put("video", true)) }) { Text("Video") }
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), reverseLayout = true) {
                items(msgs.reversed()) { m ->
                    Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (m.mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            shape = MaterialTheme.shapes.medium) { Text(m.text, Modifier.padding(10.dp)) }
                    }
                }
            }
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Message") })
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    if (text.isNotBlank()) {
                        Signaling.send(peer, "msg", JSONObject().put("text", text))
                        db.add(peer, true, text); text = ""; tick++
                    }
                }) { Text("Send") }
            }
        }
    }

    @Composable
    fun CallScreen() {
        Box(Modifier.fillMaxSize()) {
            remoteTrack?.let { VideoView(it, Modifier.fillMaxSize()) } ?: Text("In call with $chatPeer…", Modifier.align(Alignment.Center))
            localTrack?.let { VideoView(it, Modifier.align(Alignment.TopEnd).padding(16.dp).size(110.dp, 160.dp)) }
            Button(onClick = { endCall(true) }, Modifier.align(Alignment.BottomCenter).padding(32.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("End call") }
        }
    }

    @Composable
    fun VideoView(track: VideoTrack, modifier: Modifier) {
        val view = remember { mutableStateOf<SurfaceViewRenderer?>(null) }
        AndroidView(modifier = modifier, factory = { c ->
            SurfaceViewRenderer(c).apply { init(egl.eglBaseContext, null); setEnableHardwareScaler(true); setZOrderMediaOverlay(true); view.value = this }
        })
        DisposableEffect(track, view.value) {
            val v = view.value
            v?.let { track.addSink(it) }
            onDispose { v?.let { track.removeSink(it); it.release() } }
        }
    }
}
