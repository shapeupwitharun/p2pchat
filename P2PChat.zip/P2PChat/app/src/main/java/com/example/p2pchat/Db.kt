package com.example.p2pchat

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Msg(val mine: Boolean, val text: String, val ts: Long)

/** Local-only storage. Lives on this phone and nowhere else. */
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "chat.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, peer TEXT, mine INTEGER, text TEXT, ts INTEGER)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun add(peer: String, mine: Boolean, text: String) {
        writableDatabase.insert("msgs", null, ContentValues().apply {
            put("peer", peer); put("mine", if (mine) 1 else 0); put("text", text); put("ts", System.currentTimeMillis())
        })
    }
    fun list(peer: String): List<Msg> {
        val out = mutableListOf<Msg>()
        readableDatabase.rawQuery("SELECT mine,text,ts FROM msgs WHERE peer=? ORDER BY id", arrayOf(peer)).use {
            while (it.moveToNext()) out += Msg(it.getInt(0) == 1, it.getString(1), it.getLong(2))
        }
        return out
    }
    fun peers(): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT peer FROM msgs GROUP BY peer ORDER BY MAX(id) DESC", null).use {
            while (it.moveToNext()) out += it.getString(0)
        }
        return out
    }
    fun clear(peer: String) { writableDatabase.delete("msgs", "peer=?", arrayOf(peer)) }
}
