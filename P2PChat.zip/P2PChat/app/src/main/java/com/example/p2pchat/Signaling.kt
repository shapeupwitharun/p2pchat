package com.example.p2pchat

import android.os.Handler
import android.os.Looper
import okhttp3.*
import org.json.JSONObject

object Signaling {
    // TODO: put your deployed server here, e.g. "wss://my-signal.onrender.com/"
    const val URL = "ws://10.0.2.2:8080/"
    private val client = OkHttpClient()
    private val main = Handler(Looper.getMainLooper())
    private var ws: WebSocket? = null
    var onMessage: (JSONObject) -> Unit = {}

    fun connect(myId: String) {
        ws = client.newWebSocket(Request.Builder().url("$URL?id=$myId").build(), object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                main.post { runCatching { onMessage(JSONObject(text)) } }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, r: Response?) {
                main.postDelayed({ connect(myId) }, 3000)
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                main.postDelayed({ connect(myId) }, 3000)
            }
        })
    }
    fun send(to: String, type: String, data: JSONObject = JSONObject()) {
        ws?.send(JSONObject().put("to", to).put("type", type).put("data", data).toString())
    }
}
