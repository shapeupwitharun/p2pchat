# P2P Chat

## 1. Server (stores nothing, relays small JSON messages)
cd server && npm install && npm start
Deploy free on Render / Railway / Fly.io (needs WebSocket support) and use the wss:// URL.

## 2. App
- Open this folder in Android Studio (it creates the Gradle wrapper).
- In app/src/main/java/com/example/p2pchat/Signaling.kt set URL to your server (wss://...).
  (ws://10.0.2.2:8080/ works for the Android emulator against a local server.)
- Build > Build Bundle(s)/APK(s) > Build APK(s). Install on both phones.

## Use
Each phone gets a 6-digit ID. Enter the friend's ID, chat, tap Voice or Video.

## Notes
- Messages are saved only in each phone's local SQLite DB. Server keeps nothing.
- Both users must be online and have the app open (no background push, no offline delivery).
- Calls are direct WebRTC (encrypted). STUN only; add a TURN server in RtcCall.kt for strict networks.
